/* *********************************************************************** *
 * File   : network.h                                 Part of Valhalla MUD *
 * Version: 1.00                                                           *
 * Author : Unknown.                                                       *
 *                                                                         *
 * Purpose: Unknown.                                                       *
 * Bugs   : Unknown.                                                       *
 * Status : Unpublished.                                                   *
 *                                                                         *
 * Copyright (C) Valhalla (This work is unpublished).                      *
 *                                                                         *
 * This work is a property of:                                             *
 *                                                                         *
 *        Valhalla I/S                                                     *
 *        Noerre Soegade 37A, 4th floor                                    *
 *        1370 Copenhagen K.                                               *
 *        Denmark                                                          *
 *                                                                         *
 * This is an unpublished work containing Valhalla confidential and        *
 * proprietary information. Disclosure, use or reproduction without        *
 * authorization of Valhalla is prohobited.                                *
 * *********************************************************************** */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>

#define DEF_CONNECTIONS 4
#define DEF_SERVER_PORT 4242
#define DEF_SERVER_ADDR "127.0.0.1"

int OpenNetwork(char *pcAddress, int nPort, struct sockaddr_in *server_addr);
int TransmitChunk(int fd, char *buf, int n);
int ReceiveChunk(int fd, char *buf, int max);
int CloseNetwork(int fd);
