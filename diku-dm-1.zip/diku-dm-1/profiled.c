/* ex: set expandtab ts=3:                                                 */
/* -*- Mode: C; tab-width:3 -*-                                            */

static const char rcsid[] = "$Id: profiled.c,v 1.1 2003/12/13 21:03:00 fizzfaldt Exp $";

/*
   This file is included only when making a profiled build.
   It will simply have the profiled.c rcsid string
   in the binary so that we know it is a profiled build
   from the log.
*/
